-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cocktail_sense
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('1bnJLbaSTYM39yXkFRbJRBIG6hQrm0ps',1707410607,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"1bnJLbaSTYM39yXkFRbJRBIG6hQrm0ps\",\"nickname\":\"test2\"}'),('4P-tHcoKmc7UW94nE8uVafvm49aCnu75',1707410576,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"4P-tHcoKmc7UW94nE8uVafvm49aCnu75\",\"nickname\":\"test2\"}'),('6qEdcBcbuAW9tGp8TA2bTycLVKgiP-Pw',1707411905,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"6qEdcBcbuAW9tGp8TA2bTycLVKgiP-Pw\",\"nickname\":\"test2\"}'),('8TvfpJCO0MDM_JeMrurQ_hRPnYtMRGTP',1707414025,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"msg\":\"아이디 정보가 일치하지 않습니다.\"}'),('9zP0bSotDgJ1g_j0gyRhem1ql8e_0pgC',1707413298,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"9zP0bSotDgJ1g_j0gyRhem1ql8e_0pgC\",\"nickname\":\"test2\"}'),('DpCeegNKtgLif8WZSMBpHOSf-yofo58O',1707410495,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('ExyV5Ht_x4dbRq3FGAWmT-GGQKCmFBOb',1707414113,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"ExyV5Ht_x4dbRq3FGAWmT-GGQKCmFBOb\",\"msg\":\"성공\",\"nickname\":\"test2\"}'),('H-qgBhGjR0ZOR4UxsGlJvvEqXrYcLcPe',1707414041,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":false,\"msg\":\"비밀번호 정보가 일치하지 않습니다.\"}'),('HlhXzk_M9WIlO1e6DtI8ZVRer83aS6KC',1707413684,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"HlhXzk_M9WIlO1e6DtI8ZVRer83aS6KC\",\"nickname\":\"test2\"}'),('I3DU8No6i5afpJNm4sE2hjTg8iAjnSPG',1707406809,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('LLLh9XLMcca3USWPbCpvBnf_uYPqR_9Q',1707413434,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"LLLh9XLMcca3USWPbCpvBnf_uYPqR_9Q\",\"nickname\":\"test2\"}'),('LTyf5_6G3vx3WilLMzFHRf2Av-pApbYW',1707414003,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"msg\":\"아이디 정보가 일치하지 않습니다.\"}'),('TV883Ul-RVXQmXrBVsJY3ZZ0tSvDh9me',1707403096,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('Tid4wboTx4XMIPr1DRU4Ec6AAsG7bw5S',1707406444,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('XwNb64Use3FVDW17vHzHSkQmbHkDKfda',1707410470,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('Yvj85Znsq6S_djSKQdvLm0jg-Lkghx4R',1707406710,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('YxOmOQBWCihjh3W1trh9kakXBx9vVtwV',1707406743,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('_gGU34iCrfRoxxwSviiCt0eBDFTkkWoo',1707408195,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('cuTH2kgM9J2syh5R716vMJ0w0N3waYkx',1707414186,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"cuTH2kgM9J2syh5R716vMJ0w0N3waYkx\",\"msg\":\"성공\",\"nickname\":\"test2\"}'),('kA0QGrzfi5HtEpWopBheUfwiu2MhW51W',1707414062,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"kA0QGrzfi5HtEpWopBheUfwiu2MhW51W\",\"msg\":\"성공\",\"nickname\":\"test2\"}'),('oIYc8EPgVg-f2TCtuJbfBhBGRpWEfM-W',1707403043,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('pxn3fbY8JEKa7ogFcAO1S7uQFcmnOaH2',1707410421,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('qruBkkZgda9eZELusNwDtUkiq9iMKSza',1707410399,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":true,\"nickname\":\"test2\"}'),('sau93muWYynhN8mcBiyfUqBr6AL6hjfH',1707414046,'{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"httpOnly\":true,\"path\":\"/\"},\"is_logined\":\"sau93muWYynhN8mcBiyfUqBr6AL6hjfH\",\"msg\":\"성공\",\"nickname\":\"test2\"}');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-12 13:48:01
